package com.oracle.javafx.scenebuilder.app;

import java.io.File;
import java.io.IOException;
import java.net.URL;

import com.oracle.javafx.scenebuilder.app.DocumentWindowController.ActionStatus;
import com.oracle.javafx.scenebuilder.app.DocumentWindowController.DocumentControlAction;
import com.oracle.javafx.scenebuilder.app.DocumentWindowController.DocumentEditAction;
import com.oracle.javafx.scenebuilder.app.menubar.MenuBarController;
import com.oracle.javafx.scenebuilder.app.preview.PreviewWindowController;
import com.oracle.javafx.scenebuilder.kit.editor.EditorController;
import com.oracle.javafx.scenebuilder.kit.editor.panel.content.ContentPanelController;
import com.oracle.javafx.scenebuilder.kit.editor.panel.hierarchy.AbstractHierarchyPanelController;
import com.oracle.javafx.scenebuilder.kit.editor.panel.hierarchy.AbstractHierarchyPanelController.DisplayOption;
import com.oracle.javafx.scenebuilder.kit.editor.panel.library.LibraryPanelController.DISPLAY_MODE;

import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.stage.Stage;

/********************************
 *	프로젝트 : S
 *	패키지   :
 *	작성일   : 2016. 10. 20.
 *	작성자   : KYJ
 *******************************/

/**
 * @author KYJ
 *
 */
public class EmbeddedScenebuilderComposite {

	private TabPane tabPane;
	private final DocumentWindowController newWindow;
//	private EditorController editorController;
	private String title = "New";
//	private DocumentWatchingController watchingController;
	public DocumentWindowController getDocumentWindowController() {
		return newWindow;
	}

	public EmbeddedScenebuilderComposite(TabPane tabPane) {
		this.tabPane = tabPane;
		newWindow = new DocumentWindowController(this) {

			private Parent root;

			/* (non-Javadoc)
			 * @see com.oracle.javafx.scenebuilder.kit.editor.panel.util.AbstractWindowController#getRoot()
			 */
			@Override
			public Parent getRoot() {
				Parent root = super.getRoot();
				return root;
			}

			/* (non-Javadoc)
			 * @see com.oracle.javafx.scenebuilder.kit.editor.panel.util.AbstractWindowController#getScene()
			 */
			@Override
			public Scene getScene() {
				return null;
				//				return super.getScene();
			}

			protected void makeRoot() {
				final FXMLLoader loader = new FXMLLoader();

				loader.setController(this);
				loader.setLocation(getFxmlURL());
				loader.setResources(getResources());
				try {
					root = loader.load();
					setRoot(root);
					controllerDidLoadFxml();
				} catch (RuntimeException | IOException x) {
					System.out.println("loader.getController()=" + loader.getController());
					System.out.println("loader.getLocation()=" + loader.getLocation());
					throw new RuntimeException("Failed to load " + getFxmlURL().getFile(), x); //NOI18N
				}
			}

			/* (non-Javadoc)
			 * @see com.oracle.javafx.scenebuilder.kit.editor.panel.util.AbstractWindowController#getStage()
			 */
			@Override
			public Stage getStage() {
				return RunTest.MasterTab.primaryStage;
			}

		};


		//		DocumentWatchingController documentWatchingController = new DocumentWatchingController(newWindow);
		//		SBSettings.setWindowIcon(newWindow.getStage());


//		editorController = newWindow.getEditorController();
//		watchingController = newWindow.getWatchingController();
		// Starts watching document:
		//      - editorController watches files referenced from the FXML text
		//      - watchingController watches the document file, i18n resources,
//		        preview stylesheets...
//		assert editorController.isFileWatchingStarted() == false;
//		editorController.startFileWatching();
//		watchingController.start();

		//		getChildren().add(newWindow.getRoot());

		newWindow.loadWithDefaultContent();
	}

	public void openWindow() {

//		if (getStage().isShowing() == false) {
			assert newWindow.getEditorController().isFileWatchingStarted() == false;
			newWindow.getEditorController().startFileWatching();
//			newWindow.editorController.startFileWatching();
			newWindow.getWatchingController().start();
//		}

		Tab e = new Tab(getTitle());
		e.setContent(getRoot());
		this.tabPane.getTabs().add(e);
		this.tabPane.getSelectionModel().selectLast();
		newWindow.controllerDidCreateStage();

		//		primaryStage.setScene(new Scene(getRoot()));
		//		primaryStage.setScene(newWindow.getScene());
		//		primaryStage.show();
	}

	private String getTitle() {
		return this.title;
	}

	public Parent getRoot() {
		return newWindow.getRoot();
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @return
	 */
	public EditorController getEditorController() {
		return newWindow.getEditorController();
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @return
	 */
	public boolean isUnused() {
		return newWindow.isUnused();
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @return
	 */
	public MenuBarController getMenuBarController() {
		return newWindow.getMenuBarController();
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @return
	 */
	public Stage getStage() {
		return RunTest.MasterTab.primaryStage;
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @param url
	 */
	public void loadFromURL(URL fxmlURL) {
		newWindow.loadFromURL(fxmlURL);
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @return
	 */
	public boolean isFrontDocumentWindow() {
		return newWindow.isFrontDocumentWindow();
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 */
	public void performCloseFrontDocumentWindow() {
		newWindow.performCloseFrontDocumentWindow();
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @param fxmlFile
	 * @throws IOException
	 */
	public void loadFromFile(File fxmlFile) throws IOException {
		newWindow.loadFromFile(fxmlFile);
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @return
	 */
	public boolean isDocumentDirty() {
		return newWindow.isDocumentDirty();
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @return
	 */
	public ActionStatus performCloseAction() {
		return newWindow.performCloseAction();
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 */
	public void updatePreferences() {
		newWindow.updatePreferences();
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 */
	public void closeWindow() {

		Tab selectedItem = tabPane.getSelectionModel().getSelectedItem();
		if (null != selectedItem) {
			tabPane.getTabs().remove(selectedItem);
		}
//		newWindow.closeWindow();
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @param toolStylesheet
	 */
	public void setToolStylesheet(String toolStylesheet) {
		newWindow.setToolStylesheet(toolStylesheet);
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @return
	 */
	public ContentPanelController getContentPanelController() {
		return newWindow.getContentPanelController();
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @return
	 */
	public boolean isLibraryPanelVisible() {
		return newWindow.isLibraryPanelVisible();
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @return
	 */
	public boolean isHierarchyPanelVisible() {
		return newWindow.isHierarchyPanelVisible();
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @return
	 */
	public boolean isBottomPanelVisible() {
		return newWindow.isBottomPanelVisible();
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @return
	 */
	public boolean isLeftPanelVisible() {
		return newWindow.isLeftPanelVisible();
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @return
	 */
	public boolean isRightPanelVisible() {
		return newWindow.isRightPanelVisible();
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @return
	 */
	public File getResourceFile() {
		return newWindow.getResourceFile();
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @param editAction
	 * @return
	 */
	public boolean canPerformEditAction(DocumentEditAction editAction) {
		return newWindow.canPerformEditAction(editAction);
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @param editAction
	 */
	public void performEditAction(DocumentEditAction editAction) {
		newWindow.performEditAction(editAction);

	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @param controlAction
	 * @return
	 */
	public boolean canPerformControlAction(DocumentControlAction controlAction) {

		return newWindow.canPerformControlAction(controlAction);
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @param controlAction
	 */
	public void performControlAction(DocumentControlAction controlAction) {
		newWindow.performControlAction(controlAction);

	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @return
	 */
	public PreviewWindowController getPreviewWindowController() {
		return newWindow.getPreviewWindowController();
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @return
	 */
	public SceneStyleSheetMenuController getSceneStyleSheetMenuController() {
		return newWindow.getSceneStyleSheetMenuController();
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @param libraryDisplayOption
	 */
	public void refreshLibraryDisplayOption(DISPLAY_MODE libraryDisplayOption) {
		newWindow.refreshLibraryDisplayOption(libraryDisplayOption);

	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @param hierarchyDisplayOption
	 */
	public void refreshHierarchyDisplayOption(DisplayOption hierarchyDisplayOption) {
		newWindow.refreshHierarchyDisplayOption(hierarchyDisplayOption);

	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @return
	 */
	public AbstractHierarchyPanelController getHierarchyPanelController() {
		return newWindow.getHierarchyPanelController();
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 20.
	 * @param cssTableColumnsOrderingReversed
	 */
	public void refreshCssTableColumnsOrderingReversed(boolean cssTableColumnsOrderingReversed) {
		newWindow.refreshCssTableColumnsOrderingReversed(cssTableColumnsOrderingReversed);

	}

}
