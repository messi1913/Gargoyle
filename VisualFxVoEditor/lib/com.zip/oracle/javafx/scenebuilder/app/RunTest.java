package com.oracle.javafx.scenebuilder.app;

import java.nio.file.Path;

import com.oracle.javafx.scenebuilder.app.AppPlatform;
import com.oracle.javafx.scenebuilder.app.SceneBuilderApp;
import com.oracle.javafx.scenebuilder.kit.library.user.UserLibrary;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.scene.Scene;
import javafx.scene.control.TabPane;
import javafx.stage.Stage;

/********************************
 *	프로젝트 : S
 *	패키지   :
 *	작성일   : 2016. 10. 14.
 *	작성자   : KYJ
 *******************************/

/**
 * @author KYJ
 *
 */
public class RunTest extends Application {

	private UserLibrary userLibrary;

	public static class MasterTab {

		public static TabPane tabPane = new TabPane();

		public static Stage primaryStage;
	}

	@Override
	public void start(Stage primaryStage) throws Exception {
		MasterTab.primaryStage = primaryStage;



		String userLibraryFolder = AppPlatform.getUserLibraryFolder();
		userLibrary = new UserLibrary(userLibraryFolder);
		userLibrary.explorationCountProperty().addListener((ChangeListener<Number>) (ov, t, t1) -> userLibraryExplorationCountDidChange());
		userLibrary.startWatching();

		TabPane tabPane = MasterTab.tabPane;

		new SceneBuilderApp() {

			public UserLibrary getUserLibrary() {
				return userLibrary;
			}
		};

//		SceneBuilderApp.getSingleton().makeNewWindow();
		EmbeddedScenebuilderComposite embeddedScenebuilderComposite  = SceneBuilderApp.getSingleton().makeNewWindow(); /*new EmbeddedScenebuilderComposite(tabPane);*/
		embeddedScenebuilderComposite.openWindow();
		primaryStage.setScene(new Scene(tabPane));
		primaryStage.show();
	}

	//TODO 변경했음.
	protected void userLibraryExplorationCountDidChange() {
		// We can have 0, 1 or N FXML file, same for JAR one.
		final int numOfFxmlFiles = userLibrary.getFxmlFileReports().size();
		final int numOfJarFiles = userLibrary.getJarReports().size();
		final int jarCount = userLibrary.getJarReports().size();
		final int fxmlCount = userLibrary.getFxmlFileReports().size();

		switch (numOfFxmlFiles + numOfJarFiles) {
		case 0: // Case 0-0
			final int previousNumOfJarFiles = userLibrary.getPreviousJarReports().size();
			final int previousNumOfFxmlFiles = userLibrary.getPreviousFxmlFileReports().size();
			if (previousNumOfFxmlFiles > 0 || previousNumOfJarFiles > 0) {
				System.out.println("log.user.exploration.0");
			}
			break;
		case 1:
			Path path;
			if (numOfFxmlFiles == 1) { // Case 1-0
				path = userLibrary.getFxmlFileReports().get(0);
			} else { // Case 0-1
				path = userLibrary.getJarReports().get(0).getJar();
			}
			System.out.printf("log.user.exploration.1", path.getFileName());
			break;
		default:
			switch (numOfFxmlFiles) {
			case 0: // Case 0-N
				System.out.printf("log.user.jar.exploration.n", jarCount);
				break;
			case 1:
				final Path fxmlName = userLibrary.getFxmlFileReports().get(0).getFileName();
				if (numOfFxmlFiles == numOfJarFiles) { // Case 1-1
					final Path jarName = userLibrary.getJarReports().get(0).getJar().getFileName();
					System.out.printf("log.user.fxml.jar.exploration.1.1", fxmlName, jarName);
				} else { // Case 1-N
					System.out.printf("log.user.fxml.jar.exploration.1.n", fxmlName, jarCount);
				}
				break;
			default:
				switch (numOfJarFiles) {
				case 0: // Case N-0
					System.out.printf("log.user.fxml.exploration.n", fxmlCount);
					break;
				case 1: // Case N-1
					final Path jarName = userLibrary.getJarReports().get(0).getJar().getFileName();
					System.out.printf("log.user.fxml.jar.exploration.n.1", fxmlCount, jarName);
					break;
				default: // Case N-N
					System.out.printf("log.user.fxml.jar.exploration.n.n", fxmlCount, jarCount);
					break;
				}
				break;
			}
			break;
		}
	}

	/**
	 * @작성자 : KYJ
	 * @작성일 : 2016. 10. 14.
	 * @param args
	 */
	public static void main(String[] args) {
		launch(args);
	}

}
