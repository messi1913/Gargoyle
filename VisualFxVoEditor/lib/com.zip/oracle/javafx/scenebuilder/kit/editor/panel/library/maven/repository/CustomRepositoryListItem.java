package com.oracle.javafx.scenebuilder.kit.editor.panel.library.maven.repository;

public class CustomRepositoryListItem extends RepositoryListItem {

    public CustomRepositoryListItem(RepositoryManagerController repositoryDialogController, Repository repository) {
        super(repositoryDialogController, repository);
    }

}
