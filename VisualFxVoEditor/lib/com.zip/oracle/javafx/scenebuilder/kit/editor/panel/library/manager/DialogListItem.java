package com.oracle.javafx.scenebuilder.kit.editor.panel.library.manager;

public interface DialogListItem {
    
    LibraryDialogController getLibraryDialogController();
    
}
