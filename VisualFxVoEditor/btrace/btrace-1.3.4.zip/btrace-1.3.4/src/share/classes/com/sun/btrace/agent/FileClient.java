/*
 * Copyright 2008-2010 Sun Microsystems, Inc.  All Rights Reserved.
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER.
 *
 * This code is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License version 2 only, as
 * published by the Free Software Foundation.  Sun designates this
 * particular file as subject to the "Classpath" exception as provided
 * by Sun in the LICENSE file that accompanied this code.
 *
 * This code is distributed in the hope that it will be useful, but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * version 2 for more details (a copy is included in the LICENSE file that
 * accompanied this code).
 *
 * You should have received a copy of the GNU General Public License version
 * 2 along with this work; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * Please contact Sun Microsystems, Inc., 4150 Network Circle, Santa Clara,
 * CA 95054 USA or visit www.sun.com if you need additional information or
 * have any questions.
 */
package com.sun.btrace.agent;

import com.sun.btrace.comm.Command;
import com.sun.btrace.comm.DataCommand;
import com.sun.btrace.comm.ErrorCommand;
import com.sun.btrace.comm.ExitCommand;
import com.sun.btrace.comm.InstrumentCommand;
import java.lang.instrument.Instrumentation;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Timer;
import java.util.TimerTask;

/**
 * Represents a local client communicated by trace file.
 * The trace script is specified as a File of a .class file
 * or a byte array containing bytecode of the trace script.
 *
 * @author A. Sundararajan
 * @author J.Bachorik
 */
class FileClient extends Client {
    private final Timer flusher;

    private volatile PrintWriter out;

    FileClient(Instrumentation inst, byte[] code, PrintWriter traceWriter) throws IOException {
        super(inst);
        this.out = traceWriter;
        InstrumentCommand cmd = new InstrumentCommand(code, new String[0]);
        Class btraceClazz = loadClass(cmd);
        if (btraceClazz == null) {
            throw new RuntimeException("can not load BTrace class");
        }

        int flushInterval;
        String flushIntervalStr = System.getProperty("com.sun.btrace.FileClient.flush", "5");
        try {
            flushInterval = Integer.parseInt(flushIntervalStr);
        } catch (NumberFormatException e) {
            flushInterval = 5; // default
        }

        final int flushSec  = flushInterval;

        flusher = new Timer("BTrace FileClient Flusher", true);
        flusher.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                out.flush();
            }
        }, flushSec, flushSec);
    }

    FileClient(Instrumentation inst, File scriptFile, PrintWriter traceWriter) throws IOException {
        this(inst, readAll(scriptFile), traceWriter);
    }

    public void onCommand(Command cmd) throws IOException {
        if (out == null) {
            throw new IOException("no output stream");
        }
        if (debug) {

            Main.debugPrint("client " + getClassName() + ": got " + cmd);
        }
        switch (cmd.getType()) {
            case Command.EXIT:
                onExit(((ExitCommand) cmd).getExitCode());
                break;
            case Command.ERROR: {
                ErrorCommand ecmd = (ErrorCommand) cmd;
                Throwable cause = ecmd.getCause();
                cause.printStackTrace(out);
                break;
            }
            default:
                if (cmd instanceof DataCommand) {
                    ((DataCommand) cmd).print(out);
                }
                break;
        }
    }

    protected synchronized void closeAll() throws IOException {
        flusher.cancel();
        if (out != null) {
            out.close();
        }
    }

    private static byte[] readAll(File file) throws IOException {
        int size = (int) file.length();
        FileInputStream fis = new FileInputStream(file);
        try {
            byte[] buf = new byte[size];
            fis.read(buf);
            return buf;
        } finally {
            fis.close();
        }
    }
}
